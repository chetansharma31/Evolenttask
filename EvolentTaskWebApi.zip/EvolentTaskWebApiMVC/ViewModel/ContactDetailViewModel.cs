﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApiMVC.Models;

namespace WebApiMVC.ViewModel
{
    public class ContactDetailViewModel
    {
        public ContactDetail contactDetail { get; set; }
    }
}