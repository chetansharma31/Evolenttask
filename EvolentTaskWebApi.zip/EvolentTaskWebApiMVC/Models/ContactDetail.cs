﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApiMVC.Models
{
    public class ContactDetail
    {

        [Display(Name = "ContactID")]
        public int ContactID { get; set; }
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }
        [Display(Name = "LastName")]
        public string LastName { get; set; }
        [Display(Name = "Email")]
        public string Email { get; set; } 
        [Display(Name = "PhoneNumber")]
        public int PhoneNumber { get; set; } 
        [Display(Name = "Status")]
        public bool Status { get; set; }
    }
}