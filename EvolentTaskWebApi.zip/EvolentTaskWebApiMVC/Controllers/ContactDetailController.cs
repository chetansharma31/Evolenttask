﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApiMVC.Models;
using WebApiMVC.ViewModel;
using Newtonsoft.Json;

namespace WebApiMVC.Controllers
{
    public class ContactDetailController : Controller
    {
        // GET: ContactDetail  
        public ActionResult Index()
        {
            ContactDetailClient CC = new ContactDetailClient();
            ViewBag.listcontactDetails = CC.findAll();

            return View();
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View("Create");
        }
        [HttpPost]
        public ActionResult Create(ContactDetailViewModel cvm)
        {
            ContactDetailClient CC = new ContactDetailClient();
            if (CC.Create(cvm.contactDetail))
            {
                ViewBag.Message = "Contact Created Successfully!";
                ViewBag.Status = true;
            }
            else
            {
                ViewBag.Message = "An Error Occured While your transaction";
                ViewBag.Status = false;
            }
            ViewBag.listcontactDetails = CC.findAll();
            return View("Index");
        }

        public ActionResult Delete(int id)
        {
            ContactDetailClient CC = new ContactDetailClient();

            if (CC.Delete(id))
            {
                ViewBag.Message = "Contact Deleted Successfully!";
                ViewBag.Status = true;
            }
            else
            {
                ViewBag.Message = "An Error Occured While your transaction";
                ViewBag.Status = false;
            }
            ViewBag.listcontactDetails = CC.findAll();
            return View("Index");
        }
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            ContactDetailClient CC = new ContactDetailClient();
            ContactDetailViewModel CVM = new ContactDetailViewModel();
            CVM.contactDetail = CC.find(id);
            return View("Edit", CVM);
        }
        [HttpPost]
        public ActionResult Edit(ContactDetailViewModel CVM)
        {
            ContactDetailClient CC = new ContactDetailClient();

            if (CC.Edit(CVM.contactDetail))
            {
                ViewBag.Message = "Contact Updated Successfully!";
                ViewBag.Status = true;
            }
            else
            {
                ViewBag.Message = "An Error Occured While your transaction";
                ViewBag.Status = false;
            }
            ViewBag.listcontactDetails = CC.findAll();
            return View("Index");
        }
    }
}