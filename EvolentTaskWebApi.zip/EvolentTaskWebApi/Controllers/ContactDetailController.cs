﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using EvolentTaskWebApi.Models;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class ContactDetailController : ApiController
    {
        private EvolentTaskEntities db = new EvolentTaskEntities();

        // GET: api/ContactDetail
        public IQueryable<ContactDetail> GetContactDetail()
        {
            return db.ContactDetails;
        }

        // GET: api/ContactDetail/5
        [ResponseType(typeof(ContactDetail))]
        public IHttpActionResult GetContactDetail(int id)
        {
            ContactDetail ContactDetail = db.ContactDetails.Find(id);
            if (ContactDetail == null)
            {
                return NotFound();
            }

            return Ok(ContactDetail);
        }

        // PUT: api/ContactDetail/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutContactDetail(int id, ContactDetail ContactDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != ContactDetail.ContactID)
            {
                return BadRequest();
            }

            db.Entry(ContactDetail).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ContactDetail
        [ResponseType(typeof(ContactDetail))]
        public IHttpActionResult PostContactDetail(ContactDetail ContactDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ContactDetails.Add(ContactDetail);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = ContactDetail.ContactID }, ContactDetail);
        }

        // DELETE: api/ContactDetail/5
        [ResponseType(typeof(ContactDetail))]
        public IHttpActionResult DeleteContactDetail(int id)
        {
            ContactDetail ContactDetail = db.ContactDetails.Find(id);
            if (ContactDetail == null)
            {
                return NotFound();
            }

            db.ContactDetails.Remove(ContactDetail);
            db.SaveChanges();

            return Ok(ContactDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ContactDetailExists(int id)
        {
            return db.ContactDetails.Count(e => e.ContactID == id) > 0;
        }
    }
}